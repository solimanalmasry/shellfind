<?php
//
//          By Eg.prince
//
set_time_limit(0);
error_reporting(0);
$list['front'] ="2.php
3.php
4.php
5.php
6.php
7.php
8.php
9.php
10.php
12.php
11.php
123.php
1234.php";
$list['end'] = "hacker.php
hacked.php
sea.php
web.php
root.php
up.php
yeah.php
fuck.php
upload.php
anon.php
anonghost.php
anonymous.php
lol.php
anon.php
k2ll33d.php
k2ll.php
Uploader.php
up
upload
WSO.php
dz.php
DZ.php
cpanel.php
cpn.php
sos.php
term.php
Sec-War.php
sql.php
b374.php
ssl.php
mysql.php
WolF.php
madspot.php
Cgishell.pl
killer.php
changeall.php
2.php
Sh3ll.php
dz0.php
dam.php
user.php
dom.php
whmcs.php
vb.zip
r00t.php
c99.php
ro0t.php
r0ot.php
gaza.php
1.php
wp.zip
wp-content/plugins/disqus-comment-system/disqus.php
d0mains.php
wp-content/plugins/akismet/akismet.php
madspotshell.php
info.php
egyshell.php
Sym.php
c22.php
c100.php
spider.php
wp-content/plugins/akismet/admin.php
configuration.php
g.php
wp-content/plugins/google-sitemap-generator/sitemap-core.php
wp-content/plugins/akismet/widget.php
xx.pl
ls.php
Cpanel.php
k.php
zone-h.php
tmp/user.php
tmp/Sym.php
cp.php
tmp/madspotshell.php
tmp/root.php
tmp/whmcs.php
tmp/index.php
tmp/2.php
tmp/dz.php
tmp/cpn.php
tmp/changeall.php
tmp/Cgishell.pl
tmp/sql.php
0day.php
tmp/admin.php
cliente/downloads/h4xor.php
whmcs/downloads/dz.php
L3b.php
d.php
tmp/d.php
tmp/L3b.php
wp-content/plugins/akismet/admin.php
templates/rhuk_milkyway/index.php
templates/beez/index.php
sado.php
admin1.php
upload.php
up.php
vb.zip
vb.rar
admin2.asp
uploads.php
sa.php
sysadmins/
admin1/
sniper.php
administration/Sym.php
images/Sym.php
r57.php
/wp-content/plugins/disqus-comment-system/disqus.php
gzaa_spysl
sql-new.php
/shell.php
/sa.php
/admin.php
/sa2.php
/2.php
/gaza.php
/up.php
/upload.php
/uploads.php
/templates/beez/index.php
shell.php
/amad.php
/t00.php
/dz.php
/site.rar
/Black.php
/site.tar.gz
/home.zip
/home.rar
/home.tar
/home.tar.gz
forum.zip
/forum.rar
/forum.tar
/forum.tar.gz
/test.txt
/ftp.txt
/user.txt
/site.txt
/error_log
/error
/cpanel
/awstats
/site.sql
/vb.sql
/forum.sql
r00t-s3c.php
c.php
/backup.sql
/back.sql
/data.sql
wp.rar
wp-content/plugins/disqus-comment-system/disqus.php
asp.aspx
/templates/beez/index.php
tmp/vaga.php
tmp/killer.php
whmcs.php
abuhlail.php
tmp/killer.php
tmp/domaine.pl
tmp/domaine.php
useradmin
tmp/d0maine.php
d0maine.php
tmp/sql.php
X.php
123.php
m.php
b.php
up.php
tmp/dz1.php
dz1.php
forum.zip
Symlink.php
Symlink.pl
forum.rar
joomla.zip
joomla.rar
wp.php
buck.sql
sysadmin.php
images/c99.php
xd.php
love.php
hi.php
hello.php
Hello.php
c100.php
spy.aspx
xd.php
tmp/xd.php
sym/root/home/
billing/killer.php
tmp/upload.php
tmp/admin.php
Server.php
tmp/uploads.php
tmp/up.php
Server/
wp-admin/c99.php
tmp/priv8.php
priv8.php
cgi.pl/
tmp/cgi.pl
downloads/dom.php
templates/ja-helio-farsi/index.php
webadmin.html
admins.php
/wp-content/plugins/count-per-day/js/yc/d00.php
bluff.php
king.jeen
admins/
admins.asp
admins.php
wp.zip
/wp-content/plugins/disqus-comment-system/WSO.php
/wp-content/plugins/disqus-comment-system/dz.php
/wp-content/plugins/disqus-comment-system/DZ.php
/wp-content/plugins/disqus-comment-system/cpanel.php
/wp-content/plugins/disqus-comment-system/cpn.php
/wp-content/plugins/disqus-comment-system/sos.php
/wp-content/plugins/disqus-comment-system/term.php
/wp-content/plugins/disqus-comment-system/Sec-War.php
/wp-content/plugins/disqus-comment-system/sql.php
/wp-content/plugins/disqus-comment-system/ssl.php
/wp-content/plugins/disqus-comment-system/mysql.php
/wp-content/plugins/disqus-comment-system/WolF.php
/wp-content/plugins/disqus-comment-system/madspot.php
/wp-content/plugins/disqus-comment-system/Cgishell.pl
/wp-content/plugins/disqus-comment-system/killer.php
/wp-content/plugins/disqus-comment-system/changeall.php
/wp-content/plugins/disqus-comment-system/2.php
/wp-content/plugins/disqus-comment-system/Sh3ll.php
/wp-content/plugins/disqus-comment-system/dz0.php
/wp-content/plugins/disqus-comment-system/dam.php
/wp-content/plugins/disqus-comment-system/user.php
/wp-content/plugins/disqus-comment-system/dom.php
/wp-content/plugins/disqus-comment-system/whmcs.php
/wp-content/plugins/disqus-comment-system/vb.zip
/wp-content/plugins/disqus-comment-system/r00t.php
/wp-content/plugins/disqus-comment-system/c99.php
/wp-content/plugins/disqus-comment-system/gaza.php
/wp-content/plugins/disqus-comment-system/1.php
/wp-content/plugins/disqus-comment-system/d0mains.php
/wp-content/plugins/disqus-comment-system/madspotshell.php
/wp-content/plugins/disqus-comment-system/info.php
/wp-content/plugins/disqus-comment-system/egyshell.php
/wp-content/plugins/disqus-comment-system/Sym.php
/wp-content/plugins/disqus-comment-system/c22.php
/wp-content/plugins/disqus-comment-system/c100.php
/wp-content/plugins/disqus-comment-system/configuration.php
/wp-content/plugins/disqus-comment-system/g.php
/wp-content/plugins/disqus-comment-system/xx.pl
/wp-content/plugins/disqus-comment-system/ls.php
/wp-content/plugins/disqus-comment-system/Cpanel.php
/wp-content/plugins/disqus-comment-system/k.php
/wp-content/plugins/disqus-comment-system/zone-h.php
/wp-content/plugins/disqus-comment-system/tmp/user.php
/wp-content/plugins/disqus-comment-system/tmp/Sym.php
/wp-content/plugins/disqus-comment-system/cp.php
/wp-content/plugins/disqus-comment-system/tmp/madspotshell.php
/wp-content/plugins/disqus-comment-system/tmp/root.php
/wp-content/plugins/disqus-comment-system/tmp/whmcs.php
/wp-content/plugins/disqus-comment-system/tmp/index.php
/wp-content/plugins/disqus-comment-system/tmp/2.php
/wp-content/plugins/disqus-comment-system/tmp/dz.php
/wp-content/plugins/disqus-comment-system/tmp/cpn.php
/wp-content/plugins/disqus-comment-system/tmp/changeall.php
/wp-content/plugins/disqus-comment-system/tmp/Cgishell.pl
/wp-content/plugins/disqus-comment-system/tmp/sql.php
/wp-content/plugins/disqus-comment-system/0day.php
/wp-content/plugins/disqus-comment-system/tmp/admin.php
/wp-content/plugins/disqus-comment-system/L3b.php
/wp-content/plugins/disqus-comment-system/d.php
/wp-content/plugins/disqus-comment-system/tmp/d.php
/wp-content/plugins/disqus-comment-system/tmp/L3b.php
/wp-content/plugins/disqus-comment-system/sado.php
/wp-content/plugins/disqus-comment-system/admin1.php
/wp-content/plugins/disqus-comment-system/upload.php
/wp-content/plugins/disqus-comment-system/up.php
/wp-content/plugins/disqus-comment-system/vb.zip
/wp-content/plugins/disqus-comment-system/vb.rar
/wp-content/plugins/disqus-comment-system/admin2.asp
/wp-content/plugins/disqus-comment-system/uploads.php
/wp-content/plugins/disqus-comment-system/sa.php
/wp-content/plugins/disqus-comment-system/sysadmins/
/wp-content/plugins/disqus-comment-system/admin1/
/wp-content/plugins/disqus-comment-system/sniper.php
/wp-content/plugins/disqus-comment-system/images/Sym.php
/wp-content/plugins/disqus-comment-system/r57.php
/wp-content/plugins/disqus-comment-system/gzaa_spysl
/wp-content/plugins/disqus-comment-system/sql-new.php
/wp-content/plugins/disqus-comment-system//shell.php
/wp-content/plugins/disqus-comment-system/sa.php
/wp-content/plugins/disqus-comment-system/admin.php
/wp-content/plugins/disqus-comment-system/sa2.php
/wp-content/plugins/disqus-comment-system/2.php
/wp-content/plugins/disqus-comment-system/gaza.php
/wp-content/plugins/disqus-comment-system/up.php
/wp-content/plugins/disqus-comment-system/upload.php
/wp-content/plugins/disqus-comment-system/uploads.php
/wp-content/plugins/disqus-comment-system/shell.php
/wp-content/plugins/disqus-comment-system/amad.php
/wp-content/plugins/disqus-comment-system/t00.php
wp-content/plugins/disqus-comment-system/disqus.php
wp-content/plugins/akismet/WSO.php
wp-content/plugins/akismet/dz.php
wp-content/plugins/akismet/DZ.php
wp-content/plugins/akismet/cpanel.php
wp-content/plugins/akismet/cpn.php
wp-content/plugins/akismet/sos.php
wp-content/plugins/akismet/term.php
wp-content/plugins/akismet/Sec-War.php
wp-content/plugins/akismet/sql.php
wp-content/plugins/akismet/ssl.php
wp-content/plugins/akismet/mysql.php
wp-content/plugins/akismet/WolF.php
wp-content/plugins/akismet/madspot.php
wp-content/plugins/akismet/Cgishell.pl
wp-content/plugins/akismet/killer.php
wp-content/plugins/akismet/changeall.php
wp-content/plugins/akismet/2.php
wp-content/plugins/akismet/Sh3ll.php
wp-content/plugins/akismet/dz0.php
wp-content/plugins/akismet/dam.php
wp-content/plugins/akismet/user.php
wp-content/plugins/akismet/dom.php
wp-content/plugins/akismet/whmcs.php
wp-content/plugins/akismet/vb.zip
wp-content/plugins/akismet/r00t.php
wp-content/plugins/akismet/c99.php
wp-content/plugins/akismet/gaza.php
wp-content/plugins/akismet/1.php
wp-content/plugins/akismet/d0mains.php
wp-content/plugins/akismet/madspotshell.php
wp-content/plugins/akismet/info.phpwp-content/plugins/akismet/egyshell.php
wp-content/plugins/akismet/Sym.phpwp-content/plugins/akismet/c22.php
wp-content/plugins/akismet/c100.php
wp-content/plugins/akismet/configuration.php
wp-content/plugins/akismet/g.php
wp-content/plugins/akismet/xx.pl
wp-content/plugins/akismet/ls.php
wp-content/plugins/akismet/Cpanel.php
wp-content/plugins/akismet/k.php
wp-content/plugins/akismet/zone-h.php
wp-content/plugins/akismet/tmp/user.php
wp-content/plugins/akismet/tmp/Sym.php
wp-content/plugins/akismet/cp.php
wp-content/plugins/akismet/tmp/madspotshell.php
wp-content/plugins/akismet/tmp/root.php
wp-content/plugins/akismet/tmp/whmcs.php
wp-content/plugins/akismet/tmp/index.php
wp-content/plugins/akismet/tmp/2.php
wp-content/plugins/akismet/tmp/dz.php
wp-content/plugins/akismet/tmp/cpn.php
wp-content/plugins/akismet/tmp/changeall.php
wp-content/plugins/akismet/tmp/Cgishell.pl
wp-content/plugins/akismet/tmp/sql.php
wp-content/plugins/akismet/0day.php
wp-content/plugins/akismet/tmp/admin.php
wp-content/plugins/akismet/L3b.php
wp-content/plugins/akismet/d.php
wp-content/plugins/akismet/tmp/d.php
wp-content/plugins/akismet/tmp/L3b.php
wp-content/plugins/akismet/sado.php
wp-content/plugins/akismet/admin1.php
wp-content/plugins/akismet/upload.php
wp-content/plugins/akismet/up.php
wp-content/plugins/akismet/vb.zip
wp-content/plugins/akismet/vb.rar
wp-content/plugins/akismet/admin2.asp
wp-content/plugins/akismet/uploads.php
wp-content/plugins/akismet/sa.php
wp-content/plugins/akismet/sysadmins
/wp-content/plugins/akismet/admin1
/wp-content/plugins/akismet/sniper.php
wp-content/plugins/akismet/images/Sym.php
wp-content/plugins/akismet//r57.php
wp-content/plugins/akismet/gzaa_spysl
wp-content/plugins/akismet/sql-new.php
wp-content/plugins/akismet//shell.php
wp-content/plugins/akismet//sa.php
wp-content/plugins/akismet//admin.php
wp-content/plugins/akismet//sa2.php
wp-content/plugins/akismet//2.php
wp-content/plugins/akismet//gaza.php
wp-content/plugins/akismet//up.php
wp-content/plugins/akismet//upload.php
wp-content/plugins/akismet//uploads.php
wp-content/plugins/akismet/shell.php
wp-content/plugins/akismet//amad.php
wp-content/plugins/akismet//t00.php
wp-content/plugins/akismet//dz.php
wp-content/plugins/akismet//site.rar
wp-content/plugins/akismet//Black.php
wp-content/plugins/akismet//site.tar.gz
wp-content/plugins/akismet//home.zip
wp-content/plugins/akismet//home.rar
wp-content/plugins/akismet//home.tar
wp-content/plugins/akismet//home.tar.gz
wp-content/plugins/akismet//forum.zip
wp-content/plugins/akismet//forum.rar
wp-content/plugins/akismet//forum.tar
wp-content/plugins/akismet//forum.tar.gz
wp-content/plugins/akismet//test.txt
wp-content/plugins/akismet//ftp.txt
wp-content/plugins/akismet//user.txt
wp-content/plugins/akismet//site.txt
wp-content/plugins/akismet//error_log
wp-content/plugins/akismet//error
wp-content/plugins/akismet//cpanel
wp-content/plugins/akismet//awstats
wp-content/plugins/akismet//site.sql
wp-content/plugins/akismet//vb.sql
wp-content/plugins/akismet//forum.sql
wp-content/plugins/akismet/r00t-s3c.php
wp-content/plugins/akismet/c.php
wp-content/plugins/akismet//backup.sql
wp-content/plugins/akismet//back.sql
wp-content/plugins/akismet//data.sql
wp-content/plugins/akismet/wp.rar
/wp-content/plugins/akismet/asp.asp
xwp-content/plugins/akismet/tmp/vaga.php
wp-content/plugins/akismet/tmp/killer.php
wp-content/plugins/akismet/whmcs.php
wp-content/plugins/akismet/abuhlail.php
wp-content/plugins/akismet/tmp/killer.php
wp-content/plugins/akismet/tmp/domaine.pl
wp-content/plugins/akismet/tmp/domaine.php
wp-content/plugins/akismet/useradmin/
wp-content/plugins/akismet/tmp/d0maine.php
wp-content/plugins/akismet/d0maine.php
wp-content/plugins/akismet/tmp/sql.php
wp-content/plugins/akismet/X.php
wp-content/plugins/akismet/123.php
wp-content/plugins/akismet/m.php
wp-content/plugins/akismet/b.php
wp-content/plugins/akismet/up.php
wp-content/plugins/akismet/tmp/dz1.php
wp-content/plugins/akismet/dz1.php
wp-content/plugins/akismet/forum.zip
wp-content/plugins/akismet/Symlink.php
wp-content/plugins/akismet/Symlink.pl
wp-content/plugins/akismet/forum.rar
wp-content/plugins/akismet/joomla.zip
wp-content/plugins/akismet/joomla.rar
wp-content/plugins/akismet/wp.php
wp-content/plugins/akismet/buck.sql
wp-content/plugins/akismet/sysadmin.php
wp-content/plugins/akismet/images/c99.php
wp-content/plugins/akismet/xd.php
wp-content/plugins/akismet/c100.php
wp-content/plugins/akismet/spy.aspx
wp-content/plugins/akismet/xd.php
wp-content/plugins/akismet/tmp/xd.php
wp-content/plugins/akismet/sym/root/home/
wp-content/plugins/akismet/billing/killer.php
wp-content/plugins/akismet/tmp/upload.php
wp-content/plugins/akismet/tmp/admin.php
wp-content/plugins/akismet/Server.php
wp-content/plugins/akismet/tmp/uploads.php
wp-content/plugins/akismet/tmp/up.php
wp-content/plugins/akismet/Server/
wp-content/plugins/akismet/wp-admin/c99.php
wp-content/plugins/akismet/tmp/priv8.php
wp-content/plugins/akismet/priv8.php
wp-content/plugins/akismet/cgi.pl
/wp-content/plugins/akismet/tmp/cgi.pl
wp-content/plugins/akismet/downloads/dom.php
wp-content/plugins/akismet/webadmin.html
wp-content/plugins/akismet/admins.php
wp-content/plugins/akismet/bluff.php
wp-content/plugins/akismet/king.jeen
wp-content/plugins/akismet/admins/
wp-content/plugins/akismet/admins.asp
wp-content/plugins/akismet/admins.php
wp-content/plugins/akismet/wp.zip
wp-content/plugins/akismet/disqus.php
wp-content/plugins/google-sitemap-generator//cpanel
wp-content/plugins/google-sitemap-generator//awstats
wp-content/plugins/google-sitemap-generator//site.sql
wp-content/plugins/google-sitemap-generator//vb.sql
wp-content/plugins/google-sitemap-generator//forum.sql
wp-content/plugins/google-sitemap-generator/r00t-s3c.php
wp-content/plugins/google-sitemap-generator/c.php
wp-content/plugins/google-sitemap-generator//backup.sql
wp-content/plugins/google-sitemap-generator//back.sql
wp-content/plugins/google-sitemap-generator//data.sql
wp-content/plugins/google-sitemap-generator/wp.rar/
wp-content/plugins/google-sitemap-generator/asp.aspx
wp-content/plugins/google-sitemap-generator/tmp/vaga.php
wp-content/plugins/google-sitemap-generator/tmp/killer.php
wp-content/plugins/google-sitemap-generator/whmcs.php
wp-content/plugins/google-sitemap-generator/abuhlail.php
wp-content/plugins/google-sitemap-generator/tmp/killer.php
wp-content/plugins/google-sitemap-generator/tmp/domaine.pl
wp-content/plugins/google-sitemap-generator/tmp/domaine.php
wp-content/plugins/google-sitemap-generator/useradmin/
wp-content/plugins/google-sitemap-generator/tmp/d0maine.php
wp-content/plugins/google-sitemap-generator/d0maine.php
wp-content/plugins/google-sitemap-generator/tmp/sql.php
wp-content/plugins/google-sitemap-generator/X.php
wp-content/plugins/google-sitemap-generator/123.php
wp-content/plugins/google-sitemap-generator/m.php
wp-content/plugins/google-sitemap-generator/b.php
wp-content/plugins/google-sitemap-generator/up.php
wp-content/plugins/google-sitemap-generator/tmp/dz1.php
wp-content/plugins/google-sitemap-generator/dz1.php
wp-content/plugins/google-sitemap-generator/forum.zip
wp-content/plugins/google-sitemap-generator/Symlink.php
wp-content/plugins/google-sitemap-generator/Symlink.pl
wp-content/plugins/google-sitemap-generator/forum.rar
wp-content/plugins/google-sitemap-generator/joomla.zip
wp-content/plugins/google-sitemap-generator/joomla.rar
wp-content/plugins/google-sitemap-generator/wp.php
wp-content/plugins/google-sitemap-generator/buck.sql
wp-content/plugins/google-sitemap-generator/sysadmin.php
wp-content/plugins/google-sitemap-generator/images/c99.php
wp-content/plugins/google-sitemap-generator/xd.php
wp-content/plugins/google-sitemap-generator/c100.php
wp-content/plugins/google-sitemap-generator/spy.aspx
wp-content/plugins/google-sitemap-generator/xd.php
wp-content/plugins/google-sitemap-generator/tmp/xd.php
wp-content/plugins/google-sitemap-generator/sym/root/home/
wp-content/plugins/google-sitemap-generator/billing/killer.php
wp-content/plugins/google-sitemap-generator/tmp/upload.php
wp-content/plugins/google-sitemap-generator/tmp/admin.php
wp-content/plugins/google-sitemap-generator/Server.php
wp-content/plugins/google-sitemap-generator/tmp/uploads.php
wp-content/plugins/google-sitemap-generator/tmp/up.php
wp-content/plugins/google-sitemap-generator/Server/
wp-content/plugins/google-sitemap-generator/wp-admin/c99.php
wp-content/plugins/google-sitemap-generator/tmp/priv8.php
wp-content/plugins/google-sitemap-generator/priv8.php
wp-content/plugins/google-sitemap-generator/cgi.pl
/wp-content/plugins/google-sitemap-generator/tmp/cgi.pl
wp-content/plugins/google-sitemap-generator/downloads/dom.php
wp-content/plugins/google-sitemap-generator/webadmin.html
wp-content/plugins/google-sitemap-generator/admins.php
wp-content/plugins/google-sitemap-generator/bluff.php
wp-content/plugins/google-sitemap-generator/king.jeen
wp-content/plugins/google-sitemap-generator/admins
/wp-content/plugins/google-sitemap-generator/admins.asp
wp-content/plugins/google-sitemap-generator/admins.php
wp-content/plugins/google-sitemap-generator/wp.zip
wp-content/plugins/google-sitemap-generator/sitemap-core.php
/templates/beez/WSO.php
/templates/beez/dz.php
/templates/beez/DZ.php
/templates/beez/cpanel.php
/templates/beez/cpn.php
/templates/beez/sos.php
/templates/beez/term.php
/templates/beez/Sec-War.php
/templates/beez/sql.php
/templates/beez/ssl.php
/templates/beez/mysql.php
/templates/beez/WolF.php
/templates/beez/madspot.php
/templates/beez/Cgishell.pl
/templates/beez/killer.php
/templates/beez/changeall.php
/templates/beez/2.php
/templates/beez/Sh3ll.php
/templates/beez/dz0.php
/templates/beez/dam.php
/templates/beez/user.php
/templates/beez/dom.php
/templates/beez/whmcs.php
/templates/beez/vb.zip
/templates/beez/r00t.php
/templates/beez/c99.php
/templates/beez/gaza.php
/templates/beez/1.php
/templates/beez/d0mains.php
/templates/beez/madspotshell.php
/templates/beez/info.php
/templates/beez/egyshell.php
/templates/beez/Sym.php
/templates/beez/c22.php
/templates/beez/c100.php
/templates/beez/configuration.php
/templates/beez/g.php
/templates/beez/xx.pl
/templates/beez/ls.php
/templates/beez/Cpanel.php
/templates/beez/k.php
/templates/beez/zone-h.php
/templates/beez/tmp/user.php
/templates/beez/tmp/Sym.php
/templates/beez/cp.php
/templates/beez/tmp/madspotshell.php
/templates/beez/tmp/root.php
/templates/beez/tmp/whmcs.php
/templates/beez/tmp/index.php
/templates/beez/tmp/2.php
/templates/beez/tmp/dz.php
/templates/beez/tmp/cpn.php
/templates/beez/tmp/changeall.php
/templates/beez/tmp/Cgishell.pl
/templates/beez/tmp/sql.php
/templates/beez/0day.php
/templates/beez/tmp/admin.php
/templates/beez/L3b.php
/templates/beez/d.php
/templates/beez/tmp/d.php
/templates/beez/tmp/L3b.php
/templates/beez/sado.php
/templates/beez/admin1.php
/templates/beez/upload.php
/templates/beez/up.php
/templates/beez/vb.zip
/templates/beez/vb.rar
/templates/beez/admin2.asp
/templates/beez/uploads.php
/templates/beez/sa.php
/templates/beez/sysadmins/
/templates/beez/admin1/
/templates/beez/sniper.php
/templates/beez/images/Sym.php
/templates/beez//r57.php
/templates/beez/gzaa_spysl
/templates/beez/sql-new.php
/templates/beez//shell.php
/templates/beez//sa.php
/templates/beez//admin.php
/templates/beez//sa2.php
/templates/beez//2.php
/templates/beez//gaza.php
/templates/beez//up.php
/templates/beez//upload.php
/templates/beez//uploads.php
/templates/beez/shell.php
/templates/beez//amad.php
/templates/beez//t00.php
/templates/beez//dz.php
/templates/beez//site.rar
/templates/beez//Black.php
/templates/beez//site.tar.gz
/templates/beez//home.zip
/templates/beez//home.rar
/templates/beez//home.tar
/templates/beez//home.tar.gz
/templates/beez//forum.zip
/templates/beez//forum.rar
/templates/beez//forum.tar
/templates/beez//forum.tar.gz
/templates/beez//test.txt
/templates/beez//ftp.txt
/templates/beez//user.txt
/templates/beez//site.txt
/templates/beez//error_log
/templates/beez//error
/templates/beez//cpanel
/templates/beez//awstats
/templates/beez//site.sql
/templates/beez//vb.sql
/templates/beez//forum.sql
/templates/beez/r00t-s3c.php
/templates/beez/c.php
/templates/beez//backup.sql
/templates/beez//back.sql
/templates/beez//data.sql
/templates/beez/wp.rar/
/templates/beez/asp.aspx/
templates/beez/tmp/vaga.php/
templates/beez/tmp/killer.php/
templates/beez/whmcs.php/
templates/beez/abuhlail.php/
templates/beez/tmp/killer.php/
templates/beez/tmp/domaine.pl/
templates/beez/tmp/domaine.php/
templates/beez/useradmin/
/templates/beez/tmp/d0maine.php/
templates/beez/d0maine.php/
templates/beez/tmp/sql.php/
templates/beez/X.php
/templates/beez/123.php
/templates/beez/m.php
/templates/beez/b.php
/templates/beez/up.php
/templates/beez/tmp/dz1.php
/templates/beez/dz1.php
/templates/beez/forum.zip
/templates/beez/Symlink.php
/templates/beez/Symlink.pl
/templates/beez/forum.rar
/templates/beez/joomla.zip
/templates/beez/joomla.rar
/templates/beez/wp.php
/templates/beez/buck.sql
/templates/beez/sysadmin.php
/templates/beez/images/c99.php
/templates/beez/xd.php
/templates/beez/c100.php
/templates/beez/spy.aspx
/templates/beez/xd.php
/templates/beez/tmp/xd.php
/templates/beez/sym/root/home/
/templates/beez/billing/killer.php
/templates/beez/tmp/upload.php/
templates/beez/tmp/admin.php/
templates/beez/Server.php/
templates/beez/tmp/uploads.php
/templates/beez/tmp/up.php
/templates/beez/Server/
/templates/beez/wp-admin/c99.php
/templates/beez/tmp/priv8.php
/templates/beez/priv8.php
/templates/beez/cgi.pl/
/templates/beez/tmp/cgi.pl
/templates/beez/downloads/dom.php
/templates/beez/webadmin.html
/templates/beez/admins.php
/templates/beez/bluff.php
/templates/beez/king.jeen
/templates/beez/admins/
/templates/beez/admins.asp
/templates/beez/admins.php
/templates/beez/wp.zip
/templates/beez/index.php
/images/WSO.php
/images/dz.php
/images/DZ.php
/images/cpanel.php
/images/cpn.php
/images/sos.php
/images/term.php
/images/Sec-War.php
/images/sql.php
/images/ssl.php
/images/mysql.php
/images/WolF.php
/images/madspot.php
/images/Cgishell.pl
/images/killer.php
/images/changeall.php
/images/2.php
/images/Sh3ll.php
/images/dz0.php
/images/dam.php
/images/user.php
/images/dom.php
/images/whmcs.php
/images/vb.zip
/images/r00t.php
/images/c99.php
/images/gaza.php
/images/1.php
/images/d0mains.php
/images/madspotshell.php
/images/info.php
/images/egyshell.php
/images/Sym.php
/images/c22.php
/images/c100.php
/images/configuration.php
/images/g.php/images/xx.pl
/images/ls.php
/images/Cpanel.php
/images/k.php
/images/zone-h.php
/images/tmp/user.php
/images/tmp/Sym.php
/images/cp.php
/images/tmp/madspotshell.php
/images/tmp/root.php
/images/tmp/whmcs.php
/images/tmp/index.php
/images/tmp/2.php
/images/tmp/dz.php
/images/tmp/cpn.php
/images/tmp/changeall.php
/images/tmp/Cgishell.pl
/images/tmp/sql.php
/images/0day.php
/images/tmp/admin.php
/images/L3b.php
/images/d.php
/images/tmp/d.php
/images/tmp/L3b.php
/images/sado.php
/images/admin1.php
/images/upload.php
/images/up.php
/images/vb.zip
/images/vb.rar
/images/admin2.asp
/images/uploads.php
/images/sa.php
/images/sysadmins/
/images/admin1/
/images/sniper.php
/images/images/Sym.php
/images//r57.php
/images/gzaa_spysl
/images/sql-new.php
/images//shell.php
/images//sa.php
/images//admin.php
/images//sa2.php
/images//2.php
/images//gaza.php
/images//up.php
/images//upload.php
/images//uploads.php
/images/shell.php
/images//amad.php
/images//t00.php
/images//dz.php
/images//site.rar
/images//Black.php
/images//site.tar.gz
/images//home.zip
/images//home.rar
/images//home.tar
/images//home.tar.gz
/images//forum.zip
/images//forum.rar
/images//forum.tar
/images//forum.tar.gz
/images//test.txt
/images//ftp.txt
/images//user.txt
/images//site.txt
/images//error_log
/images//error
/images//cpanel
/images//awstats
/images//site.sql
/images//vb.sql
/images//forum.sql
/images/r00t-s3c.php
/images/c.php
/images//backup.sql
/images//back.sql
/images//data.sql
/images/wp.rar/
/images/asp.aspx
/images/tmp/vaga.php
/images/tmp/killer.php
/images/whmcs.php
/images/abuhlail.php
/images/tmp/killer.php
/images/tmp/domaine.pl
/images/tmp/domaine.php
/images/useradmin/
/images/tmp/d0maine.php
/images/d0maine.php
/images/tmp/sql.php
/images/X.php
/images/123.php
/images/m.php
/images/b.php
/images/up.php
/images/tmp/dz1.php
/images/dz1.php
/images/forum.zip
/images/Symlink.php
/images/Symlink.pl
/images/forum.rar
/images/joomla.zip
/images/joomla.rar
/images/wp.php
/images/buck.sql
/includes/WSO.php
/includes/dz.php
/includes/DZ.php
/includes/cpanel.php
/includes/cpn.php
/includes/sos.php
/includes/term.php
/includes/Sec-War.php
/includes/sql.php
/includes/ssl.php
/includes/mysql.php
/includes/WolF.php
/includes/madspot.php
/includes/Cgishell.pl
/includes/killer.php
/includes/changeall.php
/includes/2.php
/includes/Sh3ll.php
/includes/dz0.php
/includes/dam.php
/includes/user.php
/includes/dom.php
/includes/whmcs.php
/includes/vb.zip
/includes/r00t.php
/includes/c99.php
/includes/gaza.php
/includes/1.php
/includes/d0mains.php
/includes/madspotshell.php
/includes/info.php
/includes/egyshell.php
/includes/Sym.php
/includes/c22.php
/includes/c100.php
/includes/configuration.php
/includes/g.php
/includes/xx.pl
/includes/ls.php
/includes/Cpanel.php
/includes/k.php
/includes/zone-h.php
/includes/tmp/user.php
/includes/tmp/Sym.php
/includes/cp.php
/includes/tmp/madspotshell.php
/includes/tmp/root.php
/includes/tmp/whmcs.php
/includes/tmp/index.php
/includes/tmp/2.php
/includes/tmp/dz.php
/includes/tmp/cpn.php
/includes/tmp/changeall.php
/includes/tmp/Cgishell.pl
/includes/tmp/sql.php
/includes/0day.php
/includes/tmp/admin.php
/includes/L3b.php
/includes/d.php
/includes/tmp/d.php
/includes/tmp/L3b.php
/includes/sado.php
/includes/admin1.php
/includes/upload.php
/includes/up.php
/includes/vb.zip
/includes/vb.rar
/includes/admin2.asp
/includes/uploads.php
/includes/sa.php
/includes/sysadmins/
/includes/admin1/
/includes/sniper.php
/includes/images/Sym.php
/includes//r57.php
/includes/gzaa_spysl
/includes/sql-new.php
/includes//shell.php
/includes//sa.php
/includes//admin.php
/includes//sa2.php
/includes//2.php
/includes//gaza.php
/includes//up.php
/includes//upload.php
/includes//uploads.php
/includes/shell.php
/includes//amad.php
/includes//t00.php
/includes//dz.php
/includes//site.rar
/includes//Black.php
/includes//site.tar.gz
/includes//home.zip
/includes//home.rar
/includes//home.tar
/includes//home.tar.gz
/includes//forum.zip
/includes//forum.rar
/includes//forum.tar
/includes//forum.tar.gz
/includes//test.txt
/includes//ftp.txt
/includes//user.txt
/includes//site.txt
/includes//error_log
/includes//error
/includes//cpanel
/includes//awstats
/includes//site.sql
/includes//vb.sql
/includes//forum.sql
/includes/r00t-s3c.php
/includes/c.php
/includes//backup.sql
/includes//back.sql/
includes//data.sql
/includes/wp.rar/
/includes/asp.aspx
/includes/tmp/vaga.php
/includes/tmp/killer.php
/includes/whmcs.php
/includes/abuhlail.php
/includes/tmp/killer.php
/includes/tmp/domaine.pl
/includes/tmp/domaine.php
/includes/useradmin/
/includes/tmp/d0maine.php
/includes/d0maine.php
/includes/tmp/sql.php
/includes/X.php
/includes/123.php
/includes/m.php
/includes/b.php
/includes/up.php
/includes/tmp/dz1.php
/includes/dz1.php
/includes/forum.zip
/includes/Symlink.php
/includes/Symlink.pl
/includes/forum.rar
/includes/joomla.zip
/includes/joomla.rar
/includes/wp.php
/includes/buck.sql
/includes/sysadmin.php
/includes/images/c99.php
/includes/xd.php
/includes/c100.php
/includes/spy.aspx
/includes/xd.php
/includes/tmp/xd.php
/includes/sym/root/home/
/includes/billing/killer.php
/includes/tmp/upload.php
/includes/tmp/admin.php
/includes/Server.php
/includes/tmp/uploads.php
/includes/tmp/up.php
/includes/Server/
/includes/wp-admin/c99.php
/includes/tmp/priv8.php
/includes/priv8.php
/includes/cgi.pl/
/includes/tmp/cgi.pl
/includes/downloads/dom.php
/includes/webadmin.html
/includes/admins.php
/includes/bluff.php
/includes/king.jeen
/includes/admins/
/includes/admins.asp
/includes/admins.php
/includes/wp.zip
/includes/
/templates/rhuk_milkyway/WSO.php
/templates/rhuk_milkyway/dz.php
/templates/rhuk_milkyway/DZ.php
/templates/rhuk_milkyway/cpanel.php
/templates/rhuk_milkyway/cpn.php
/templates/rhuk_milkyway/sos.php
/templates/rhuk_milkyway/term.php
/templates/rhuk_milkyway/Sec-War.php
/templates/rhuk_milkyway/sql.php
/templates/rhuk_milkyway/ssl.php
/templates/rhuk_milkyway/mysql.php
/templates/rhuk_milkyway/WolF.php
/templates/rhuk_milkyway/madspot.php
/templates/rhuk_milkyway/Cgishell.pl
/templates/rhuk_milkyway/killer.php
/templates/rhuk_milkyway/changeall.php
/templates/rhuk_milkyway/2.php
/templates/rhuk_milkyway/Sh3ll.php
/templates/rhuk_milkyway/dz0.php
/templates/rhuk_milkyway/dam.php
/templates/rhuk_milkyway/user.php
/templates/rhuk_milkyway/dom.php
/templates/rhuk_milkyway/whmcs.php
/templates/rhuk_milkyway/vb.zip
/templates/rhuk_milkyway/r00t.php
/templates/rhuk_milkyway/c99.php
/templates/rhuk_milkyway/gaza.php
/templates/rhuk_milkyway/1.php
/templates/rhuk_milkyway/d0mains.php
/templates/rhuk_milkyway/madspotshell.php
/templates/rhuk_milkyway/info.php
/templates/rhuk_milkyway/egyshell.php
/templates/rhuk_milkyway/Sym.php
/templates/rhuk_milkyway/c22.php
/templates/rhuk_milkyway/c100.php
/templates/rhuk_milkyway/configuration.php
/templates/rhuk_milkyway/g.php
/templates/rhuk_milkyway/xx.pl
/templates/rhuk_milkyway/ls.php
/templates/rhuk_milkyway/Cpanel.php
/templates/rhuk_milkyway/k.php
/templates/rhuk_milkyway/zone-h.php
/templates/rhuk_milkyway/tmp/user.php
/templates/rhuk_milkyway/tmp/Sym.php
/templates/rhuk_milkyway/cp.php
/templates/rhuk_milkyway/tmp/madspotshell.php
/templates/rhuk_milkyway/tmp/root.php
/templates/rhuk_milkyway/tmp/whmcs.php
/templates/rhuk_milkyway/tmp/index.php
/templates/rhuk_milkyway/tmp/2.php
/templates/rhuk_milkyway/tmp/dz.php
/templates/rhuk_milkyway/tmp/cpn.php
/templates/rhuk_milkyway/tmp/changeall.php
/templates/rhuk_milkyway/tmp/Cgishell.pl
/templates/rhuk_milkyway/tmp/sql.php
/templates/rhuk_milkyway/0day.php
/templates/rhuk_milkyway/tmp/admin.php
/templates/rhuk_milkyway/L3b.php
/templates/rhuk_milkyway/d.php
/templates/rhuk_milkyway/tmp/d.php
/templates/rhuk_milkyway/tmp/L3b.php
/templates/rhuk_milkyway/sado.php
/templates/rhuk_milkyway/admin1.php
/templates/rhuk_milkyway/upload.php
/templates/rhuk_milkyway/up.php
/templates/rhuk_milkyway/vb.zip
/templates/rhuk_milkyway/vb.rar
/templates/rhuk_milkyway/admin2.asp
/templates/rhuk_milkyway/uploads.php
/templates/rhuk_milkyway/sa.php
/templates/rhuk_milkyway/sysadmins/
/templates/rhuk_milkyway/admin1/
/templates/rhuk_milkyway/sniper.php
/templates/rhuk_milkyway/images/Sym.php
/templates/rhuk_milkyway//r57.php
/templates/rhuk_milkyway/gzaa_spysl
/templates/rhuk_milkyway/sql-new.php
/templates/rhuk_milkyway//shell.php
/templates/rhuk_milkyway//sa.php
/templates/rhuk_milkyway//admin.php
/templates/rhuk_milkyway//sa2.php
/templates/rhuk_milkyway//2.php
/templates/rhuk_milkyway//gaza.php
/templates/rhuk_milkyway//up.php
/templates/rhuk_milkyway//upload.php
/templates/rhuk_milkyway//uploads.php
/templates/rhuk_milkyway/shell.php
/templates/rhuk_milkyway//amad.php
/templates/rhuk_milkyway//t00.php
/templates/rhuk_milkyway//dz.php
/templates/rhuk_milkyway//site.rar
/templates/rhuk_milkyway//Black.php
/templates/rhuk_milkyway//site.tar.gz
/templates/rhuk_milkyway//home.zip
/templates/rhuk_milkyway//home.rar
/templates/rhuk_milkyway//home.tar
/templates/rhuk_milkyway//home.tar.gz
/templates/rhuk_milkyway//forum.zip
/templates/rhuk_milkyway//forum.rar
/templates/rhuk_milkyway//forum.tar
/templates/rhuk_milkyway//forum.tar.gz
/templates/rhuk_milkyway//test.txt
/templates/rhuk_milkyway//ftp.txt
/templates/rhuk_milkyway//user.txt
/templates/rhuk_milkyway//site.txt
/templates/rhuk_milkyway//error_log
/templates/rhuk_milkyway//error
/templates/rhuk_milkyway//cpanel
/templates/rhuk_milkyway//awstats
/templates/rhuk_milkyway//site.sql
/templates/rhuk_milkyway//vb.sql
/templates/rhuk_milkyway//forum.sql
/templates/rhuk_milkyway/r00t-s3c.php
/templates/rhuk_milkyway/c.php
/templates/rhuk_milkyway//backup.sql
/templates/rhuk_milkyway//back.sql
/templates/rhuk_milkyway//data.sql
/templates/rhuk_milkyway/wp.rar/
/templates/rhuk_milkyway/asp.aspx
/templates/rhuk_milkyway/tmp/vaga.php
/templates/rhuk_milkyway/tmp/killer.php
/templates/rhuk_milkyway/whmcs.php
/templates/rhuk_milkyway/abuhlail.php
/templates/rhuk_milkyway/tmp/killer.php
/templates/rhuk_milkyway/tmp/domaine.pl
/templates/rhuk_milkyway/tmp/domaine.php
/templates/rhuk_milkyway/useradmin/
/templates/rhuk_milkyway/tmp/d0maine.php
/templates/rhuk_milkyway/d0maine.php
/templates/rhuk_milkyway/tmp/sql.php
/templates/rhuk_milkyway/X.php
/templates/rhuk_milkyway/123.php
/templates/rhuk_milkyway/m.php
/templates/rhuk_milkyway/b.php
/templates/rhuk_milkyway/up.php
/templates/rhuk_milkyway/tmp/dz1.php
/templates/rhuk_milkyway/dz1.php
/templates/rhuk_milkyway/forum.zip
/templates/rhuk_milkyway/Symlink.php
/templates/rhuk_milkyway/Symlink.pl
/templates/rhuk_milkyway/forum.rar
/templates/rhuk_milkyway/joomla.zip
/templates/rhuk_milkyway/joomla.rar
/templates/rhuk_milkyway/wp.php
/templates/rhuk_milkyway/buck.sql
/templates/rhuk_milkyway/sysadmin.php
/templates/rhuk_milkyway/images/c99.php
/templates/rhuk_milkyway/xd.php
/templates/rhuk_milkyway/c100.php
/templates/rhuk_milkyway/spy.aspx
/templates/rhuk_milkyway/xd.php
/templates/rhuk_milkyway/tmp/xd.php
/templates/rhuk_milkyway/sym/root/home/
/templates/rhuk_milkyway/billing/killer.php
/templates/rhuk_milkyway/tmp/upload.php
/templates/rhuk_milkyway/tmp/admin.php
/templates/rhuk_milkyway/Server.php
/templates/rhuk_milkyway/tmp/uploads.php
/templates/rhuk_milkyway/tmp/up.php
/templates/rhuk_milkyway/Server/
/templates/rhuk_milkyway/wp-admin/c99.php
/templates/rhuk_milkyway/tmp/priv8.php
/templates/rhuk_milkyway/priv8.php
/templates/rhuk_milkyway/cgi.pl/
/templates/rhuk_milkyway/tmp/cgi.pl
/templates/rhuk_milkyway/downloads/dom.php
/templates/rhuk_milkyway/webadmin.html
/templates/rhuk_milkyway/admins.php
/templates/rhuk_milkyway/bluff.php
/templates/rhuk_milkyway/king.jeen
/templates/rhuk_milkyway/admins/
/templates/rhuk_milkyway/admins.asp
/templates/rhuk_milkyway/admins.php
/templates/rhuk_milkyway/wp.zip
/templates/rhuk_milkyway/
WSO.php
a.php
z.php
e.php
r.php
t.php
y.php
u.php
i.php
o.php
p.php
q.php
s.php
d.php
f.php
g.php
h.php
j.php
k.php
l.php
m.php
w.php
x.php
c.php
v.php
b.php
n.php
1.php";
function template() {
echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="icon" href="favicon.ico" type="image/ico" sizes="16x16">
<title>Shell Finder By EGprince</title>
<style>
.ndk {
  background: #a8a8a8;
  background-image: -webkit-linear-gradient(top, #a8a8a8, #72797d);
  background-image: -moz-linear-gradient(top, #a8a8a8, #72797d);
  background-image: -ms-linear-gradient(top, #a8a8a8, #72797d);
  background-image: -o-linear-gradient(top, #a8a8a8, #72797d);
  background-image: linear-gradient(to bottom, #a8a8a8, #72797d);
  -webkit-border-radius: 3;
  -moz-border-radius: 3;
  border-radius: 3px;
  -webkit-box-shadow: 0px 1px 30px #666666;
  -moz-box-shadow: 0px 1px 30px #666666;
  box-shadow: 0px 1px 30px #666666;
  font-family: Arial;
  color: #ffffff;
  font-size: 9px;
  padding: 10px 20px 10px 20px;
  border: solid #b3adb3 4px;
  text-decoration: none;
}

.ndk:hover {
  background: #8a9094;
  background-image: -webkit-linear-gradient(top, #8a9094, #999ea1);
  background-image: -moz-linear-gradient(top, #8a9094, #999ea1);
  background-image: -ms-linear-gradient(top, #8a9094, #999ea1);
  background-image: -o-linear-gradient(top, #8a9094, #999ea1);
  background-image: linear-gradient(to bottom, #8a9094, #999ea1);
  text-decoration: none;
}
</style>
<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/earlyaccess/droidarabickufi.css" />
<body bgcolor="black">

<style>
a{
        color: white;
        text-decoration: none;
        font-weight: bold;
}
</style>
	<style type="text/css">
table.gradienttable {
	font-family: verdana,arial,sans-serif;
	font-size:11px;
	color:#333333;
	border-width: 1px;
	border-color: #575353;
	border-collapse: collapse;
}
table.gradienttable th {
	padding: 0px;
	background: #d5e3e4;
	background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2Q1ZTNlNCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjQwJSIgc3RvcC1jb2xvcj0iI2NjZGVlMCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNiM2M4Y2MiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
	background: -moz-linear-gradient(top,  #d5e3e4 0%, #ccdee0 40%, #b3c8cc 100%);
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#d5e3e4), color-stop(40%,#ccdee0), color-stop(100%,#b3c8cc));
	background: -webkit-linear-gradient(top,  #d5e3e4 0%,#ccdee0 40%,#b3c8cc 100%);
	background: -o-linear-gradient(top,  #d5e3e4 0%,#ccdee0 40%,#b3c8cc 100%);
	background: -ms-linear-gradient(top,  #d5e3e4 0%,#ccdee0 40%,#b3c8cc 100%);
	background: linear-gradient(to bottom,  #d5e3e4 0%,#ccdee0 40%,#b3c8cc 100%);
	border: 1px solid #999999;
}
table.gradienttable td {
	padding: 0px;
	background: #ebecda;
	background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2ViZWNkYSIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjQwJSIgc3RvcC1jb2xvcj0iI2UwZTBjNiIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNjZWNlYjciIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
	background: -moz-linear-gradient(top,  #ebecda 0%, #e0e0c6 40%, #ceceb7 100%);
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ebecda), color-stop(40%,#e0e0c6), color-stop(100%,#ceceb7));
	background: -webkit-linear-gradient(top,  #ebecda 0%,#e0e0c6 40%,#ceceb7 100%);
	background: -o-linear-gradient(top,  #ebecda 0%,#e0e0c6 40%,#ceceb7 100%);
	background: -ms-linear-gradient(top,  #ebecda 0%,#e0e0c6 40%,#ceceb7 100%);
	background: linear-gradient(to bottom,  #ebecda 0%,#e0e0c6 40%,#ceceb7 100%);
	border: 1px solid #999999;
}
table.gradienttable th p{
	margin:0px;
	padding:8px;
	border-top: 1px solid #eefafc;
	border-bottom:0px;
	border-left: 1px solid #eefafc;
	border-right:0px;
}
table.gradienttable td p{
	margin:0px;
	padding:8px;
	border-top: 1px solid #fcfdec;
	border-bottom:0px;
	border-left: 1px solid #fcfdec;;
	border-right:0px;
}
</style>

<center>
<center><input type="submit" class="myButton" name="xploit_submit" value="Shell Finder by EG Prince" align="center" /></center>
</center>
<center>
<h2><font color="green" face="droid arabic kufi"> Enter the Domain without [ www ] ex: Site.com</font></h2> 
</center>
<style type="text/css">
body{
        margin: 0;
        padding: 0;
        padding-top: 10px;
        color: #FFF;
        font-family: Calibri;
        font-size: 13px;
}
a{
        color: #FFF;
        text-decoration: none;
        font-weight: bold;
}
.wrapper{
        width: 800px;
        margin: 0 auto;
}
.tube{
        padding: 10px;
}
.t{
        padding: 10px;
}
.red{
        width: 800px;
        border: 1px solid #e52224;
        background: #191919;
        color: #e52224
}

}
.blue{
        float: left;
        width: 800px;
        border: 1px solid #1d7fc3;
        background: #191919;
        color: #1d7fc3;
}
.green{
        float: left;
        width: 800px;
        border: 1px solid #5fd419;
        background: #191919;
        color: #5fd419;
}
.g{
        float: center;
        width: 800px;
        border: 1px solid #5fd419;
        background: #191919;
        color: red;
}
</style>
<style>
.myButton {
	-moz-box-shadow: 0px 0px 9px 7px #00FFFF;
	-webkit-box-shadow: 0px 0px 9px 7px #00FFFF;
	box-shadow: 0px 0px 9px 7px #00FFFF;
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #242625), color-stop(1, #697364));
	background:-moz-linear-gradient(top, #242625 5%, #697364 100%);
	background:-webkit-linear-gradient(top, #242625 5%, #697364 100%);
	background:-o-linear-gradient(top, #242625 5%, #697364 100%);
	background:-ms-linear-gradient(top, #242625 5%, #697364 100%);
	background:linear-gradient(to bottom, #242625 5%, #697364 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#242625", endColorstr="#697364",GradientType=0);
	background-color:#242625;
	-moz-border-radius:8px;
	-webkit-border-radius:8px;
	border-radius:8px;
	border:5px solid #657366;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Georgia;
	font-size:19px;
	padding:9px 40px;
	text-decoration:none;
	text-shadow:0px 0px 0px #778076;
}
.myButton:hover {
	background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #697364), color-stop(1, #242625));
	background:-moz-linear-gradient(top, #697364 5%, #242625 100%);
	background:-webkit-linear-gradient(top, #697364 5%, #242625 100%);
	background:-o-linear-gradient(top, #697364 5%, #242625 100%);
	background:-ms-linear-gradient(top, #697364 5%, #242625 100%);
	background:linear-gradient(to bottom, #697364 5%, #242625 100%);
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#697364", endColorstr="#242625",GradientType=0);
	background-color:#697364;
}
.myButton:active {
	position:relative;
	top:1px;
}


</style>
<style>
.islamicstate
{ 
background:#FFFFFF;
color:#171717;
border:5px solid #00FFFF;
border-radius:4px ;
font-size:17px ;
height: 26px ;
line-height:14px ;
width: 700px ;
padding: 4px ;
box-shadow: 0px 0px 37px #000000; 
-webkit-box-shadow: 0px 0px 37px #000000; 
-moz-box-shadow: 0px 0px 37px #000000; 

</style>
<style type="text/css">
.classname {
	-moz-box-shadow:inset 0px 1px 0px 0px #ff0000;
	-webkit-box-shadow:inset 0px 1px 0px 0px #ff0000;
	box-shadow:inset 0px 1px 0px 0px #ff0000;
	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #f0f0f0), color-stop(1, #fcfcfc) );
	background:-moz-linear-gradient( center top, #f0f0f0 5%, #fcfcfc 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#f0f0f0", endColorstr="#fcfcfc");
	background-color:#f0f0f0;
	-webkit-border-top-left-radius:0px;
	-moz-border-radius-topleft:0px;
	border-top-left-radius:0px;
	-webkit-border-top-right-radius:0px;
	-moz-border-radius-topright:0px;
	border-top-right-radius:0px;
	-webkit-border-bottom-right-radius:0px;
	-moz-border-radius-bottomright:0px;
	border-bottom-right-radius:0px;
	-webkit-border-bottom-left-radius:0px;
	-moz-border-radius-bottomleft:0px;
	border-bottom-left-radius:0px;
	text-indent:0;
	border:1px solid #ff1212;
	display:inline-block;
	color:#000000;
	font-family:Arial;
	font-size:15px;
	font-weight:bold;
	font-style:normal;
	height:40px;
	line-height:40px;
	width:290px;
	text-decoration:none;
	text-align:center;
	text-shadow:1px 1px 0px #ffffff;
}
.classname:hover {
	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #fcfcfc), color-stop(1, #f0f0f0) );
	background:-moz-linear-gradient( center top, #fcfcfc 5%, #f0f0f0 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#fcfcfc", endColorstr="#f0f0f0");
	background-color:#fcfcfc;
}.classname:active {
	position:relative;
	top:1px;
}</style>
<script type="text/javascript">
<!--
function insertcode($text, $place, $replace)
{
        var $this = $text;
        var logbox = document.getElementById($place);
        if($replace == 0)
                document.getElementById($place).innerHTML = logbox.innerHTML+$this;
        else
                document.getElementById($place).innerHTML = $this;
//document.getElementById("helpbox").innerHTML = $this;
}
-->
</script>
</head>
<body>
<div class="wrapper">
<div class="green">
<div class="tube">
<form action="" method="post" name="xploit_form">
<br /><center><input placeholder="Example: Domain.com Or http://Domain.com" class="islamicstate" type="text" name="xploit_url" value="'.$_POST['xploit_url'].'" /></center><br /><br />
<center><input type="submit" class="myButton" name="xploit_submit" value="Start Find" align="center" /></center>
</form>
<br />
</div> <!-- /tube -->
</div> <!-- /green -->
<br />
<center> for more  : <a href="http://egyption-prince.blogspot.com.eg/" target="_blanck">Egyption-prince</a><br>
<font color="red" size="3">@copy Right For Eg prince</font>
</center>
<br />
<div class="green">
<div class="tube" id="rightcol">
<font size="3">Verificat: <span id="verified">0</span> / <span id="total">0</span></font><br />
<font size="3">Shell Found : </font><br />
</div> <!-- /tube -->
</div> <!-- /green -->

<div class="g">
<div class="t">
<br clear="all" /><br />
<div class="blue">
<div class="tube" id="logbox">
<br />
<br />

<center><font size="3">...:::: Starting please wait ::::...</font></center><br />
</div> <!-- /tube -->
</div> <!-- /blue -->
</div> <!-- /wrapper -->
<br clear="all">';
}
function show($msg, $br=1, $stop=0, $place='logbox', $replace=0) {
        if($br == 1) $msg .= "<br />";
        echo "<script type=\"text/javascript\">insertcode('".$msg."', '".$place."', '".$replace."');</script>";
        if($stop == 1) exit;
        @flush();@ob_flush();
}
function check($x, $front=0) {
        global $_POST,$site,$false;
        if($front == 0) $t = $site.$x;
        else $t = 'http://'.$x.'.'.$site.'/';
        $headers = get_headers($t);
        if (!eregi('200', $headers[0])) return 0;
        $data = @file_get_contents($t);
        if($_POST['xploit_404string'] == "") if($data == $false) return 0;
        if($_POST['xploit_404string'] != "") if(strpos($data, $_POST['xploit_404string'])) return 0;
        return 1;
}
       
// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
template();
if(!isset($_POST['xploit_url'])) die;
if($_POST['xploit_url'] == '') die;
$site = $_POST['xploit_url'];
if ($site[strlen($site)-1] != "/") $site .= "/";
if($_POST['xploit_404string'] == "") $false = @file_get_contents($site."d65897f5380a21a42db94b3927b823d56ee1099a-this_can-t_exist.html");
$list['end'] = str_replace("\r", "", $list['end']);
$list['front'] = str_replace("\r", "", $list['front']);
$pathes = explode("\n", $list['end']);
$frontpathes = explode("\n", $list['front']);
show(count($pathes)+count($frontpathes), 1, 0, 'total', 1);
$verificate = 0;
foreach($pathes as $path) {
        show('Finding '.$site.$path.' : ', 0, 0, 'logbox', 0);
        $verificate++; show($verificate, 0, 0, 'verified', 1);
        if(check($path) == 0) show('not found', 1, 0, 'logbox', 0);
        else{
                show('<span style="color: #00FF00;"><strong>found</strong></span>', 1, 0, 'logbox', 0);
                show('<a href="'.$site.$path.'">'.$site.$path.'</a>', 1, 0, 'rightcol', 0);
        }
}
preg_match("/\/\/(.*?)\//i", $site, $xx); $site = $xx[1];
if(substr($site, 0, 3) == "www") $site = substr($site, 4);
foreach($frontpathes as $frontpath) {
        show('Finding http://'.$frontpath.'.'.$site.'/ : ', 0, 0, 'logbox', 0);
        $verificate++; show($verificate, 0, 0, 'verified', 1);
        if(check($frontpath, 1) == 0) show('not found', 1, 0, 'logbox', 0);
        else{
                show('<span style="color: #00FF00;"><strong>found</strong></span>', 1, 0, 'logbox', 0);
                show('<a href="http://'.$frontpath.'.'.$site.'/">'.$frontpath.'.'.$site.'</a>', 1, 0, 'rightcol', 0);
        }
       
}
?>